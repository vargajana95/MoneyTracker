package vargajana95.moneytracker.ui.transactions

interface SummaryScreen {
    fun show(param: String)
}