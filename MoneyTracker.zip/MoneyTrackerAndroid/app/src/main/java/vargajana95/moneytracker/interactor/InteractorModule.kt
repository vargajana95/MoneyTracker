package vargajana95.moneytracker.interactor

import dagger.Module

@Module
class InteractorModule {
//    @Provides
//    @Singleton
//    fun provideTransactionsInteractor(ynabApi: YnabApi) = TransactionInteractor(ynabApi)
}