package vargajana95.moneytracker.ui.transactions

class TransactionsAdapter {
}