package vargajana95.moneytracker.dto

data class CategoryResponse(
    var id: String? = null,
    var name: String? = null
)
