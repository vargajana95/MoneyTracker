package vargajana95.moneytracker.dto

data class TransactionsResult (
    var data: TransactionsResultData? = null
)