package vargajana95.moneytracker.network

object NetworkConfig {
    const val API_ENDPOINT_ADDRESS = "https://api.youneedabudget.com/"
}