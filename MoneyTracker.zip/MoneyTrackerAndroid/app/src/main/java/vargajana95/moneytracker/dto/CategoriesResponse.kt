package vargajana95.moneytracker.dto

data class CategoriesResponse(
    var data: CategoriesResponseData
)