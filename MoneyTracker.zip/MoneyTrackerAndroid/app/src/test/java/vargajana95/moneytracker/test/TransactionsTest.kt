package vargajana95.moneytracker.test

class TransactionsTest {
}