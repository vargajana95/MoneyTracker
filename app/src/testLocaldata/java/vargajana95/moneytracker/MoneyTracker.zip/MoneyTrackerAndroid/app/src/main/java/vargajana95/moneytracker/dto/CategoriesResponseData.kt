package vargajana95.moneytracker.dto

data class CategoriesResponseData(
    var categoryGroups: List<CategoryGroupsResponse>
)
