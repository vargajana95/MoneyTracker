package vargajana95.moneytracker.dto

data class CreateTransactionResponse (
    var data: CreateTransactionData
)