package vargajana95.moneytracker.model

data class Category(
    var id: String,
    var name: String
)