package vargajana95.moneytracker.ui.about

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import vargajana95.moneytracker.R

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}
