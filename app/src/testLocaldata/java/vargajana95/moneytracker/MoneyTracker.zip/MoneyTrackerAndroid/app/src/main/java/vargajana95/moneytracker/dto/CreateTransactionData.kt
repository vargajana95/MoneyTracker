package vargajana95.moneytracker.dto

data class CreateTransactionData (
    var transaction: TransactionResult
)