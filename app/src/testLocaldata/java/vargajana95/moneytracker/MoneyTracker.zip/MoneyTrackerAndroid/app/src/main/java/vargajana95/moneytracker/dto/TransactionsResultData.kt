package vargajana95.moneytracker.dto

data class TransactionsResultData(
    var transactions: List<TransactionResult>
)
